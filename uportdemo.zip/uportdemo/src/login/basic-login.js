// - ***** - Boilerplate  start - ***** - 
const express = require('express')
const bodyParser = require('body-parser')
const ngrok = require('ngrok')
const decodeJWT = require('did-jwt').decodeJWT
const { Credentials } = require('uport-credentials')
const transports = require('uport-transports').transport
const message = require('uport-transports').message.util
const QRCode = require('qrcode') // - https://github.com/uport-project/uport-transports/issues/43

let endpoint = ''
const app = express();
app.use(bodyParser.json({ type: '*/*' }))

// - setup Credentials object with created application identity.
/*const credentials = require('../base/credentials.js') */  

const credentials = new Credentials({
  appName: 'Uport Login Sample',
  did: 'did:ethr:0x7b32c83e000852a61049728c25add82aafb70742',

  // - privateKey must be kept secure and encrypted and decrypted when needed
  privateKey: '77796296738e7d57de828cbe60205284e3e8d7a48df56dfc02fddc1ed6fd983b'

}) // - ***** - Boilerplate end - ***** - 

// - Selective Disclosure Request
app.get('/', (req, res) => {
  credentials.createDisclosureRequest({
    // - just requesting name
    requested: ["name"],
    notifications: true,
    // - set callbackUrl field to 'endpoint' created in app.listen below
    callbackUrl: endpoint + '/callback'
  }).then(requestToken => {
    console.log(decodeJWT(requestToken))  //log request token to console
    const uri = message.paramsToQueryString(message.messageToURI(requestToken), {callback_type: 'post'})
    // - Following line is error https://github.com/uport-project/uport-transports/issues/43
    //const qr =  transports.ui.getImageDataURI(uri)
    //res.send(`<div><img src="${qr}"/></div>`)
    
    // - replaced the two lines above with the two below
    QRCode.toDataURL(uri, function (err, url) {
    res.send(`<div><img src="${url}"/></div>`)
    })
  })
})

// - Selective Disclosure Response
app.post('/callback', (req, res) => {
  const jwt = req.body.access_token
  console.log('jwt received: ',jwt);
  credentials.authenticateDisclosureResponse(jwt).then(credentials => {
    console.log('jwt credentials: ', credentials);
    // Validate the information and apply authorization logic
  }).catch( err => {
    console.log(err)
  })
})

// run the app server and tunneling service
const server = app.listen(8088, () => {
  ngrok.connect(8088).then(ngrokUrl => {
    endpoint = ngrokUrl
    console.log(`Login Service running, open at ${endpoint}`)
  })
})
