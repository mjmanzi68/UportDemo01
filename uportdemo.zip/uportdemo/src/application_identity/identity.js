// - Create credentials object
const { Credentials } = require('uport-credentials');

// - Create the did and provateKey
const {did, privateKey} = Credentials.createIdentity()

// - Log output DID and PrivateKey
console.log ('Credentials.createIdentity()');
console.log ('did= ', did);
console.log ('privateKey= ', privateKey);
