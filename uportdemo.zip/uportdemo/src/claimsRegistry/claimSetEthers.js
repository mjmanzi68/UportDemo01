
//import { ethers } from 'ethers';  // - from doc but did not work
// import ethers from 'ethers';  // - not work
const ethers = require('ethers');

console.log('Start -------');
let debug = false; // - printout is very long

// - The connection to the network using the default: http://localhost:8545
let provider = new ethers.providers.JsonRpcProvider();  

// - The Contract interface
let contractAbi = [{"constant":false,"inputs":[{"name":"key","type":"bytes32"},{"name":"value","type":"bytes32"}],"name":"setSelfClaim","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"subject","type":"address"},{"name":"key","type":"bytes32"},{"name":"value","type":"bytes32"}],"name":"setClaim","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"issuer","type":"address"},{"name":"subject","type":"address"},{"name":"key","type":"bytes32"}],"name":"removeClaim","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"issuer","type":"address"},{"name":"subject","type":"address"},{"name":"key","type":"bytes32"}],"name":"getClaim","outputs":[{"name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"},{"name":"","type":"address"},{"name":"","type":"bytes32"}],"name":"registry","outputs":[{"name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"anonymous":false,"inputs":[{"indexed":true,"name":"issuer","type":"address"},{"indexed":true,"name":"subject","type":"address"},{"indexed":true,"name":"key","type":"bytes32"},{"indexed":false,"name":"value","type":"bytes32"},{"indexed":false,"name":"updatedAt","type":"uint256"}],"name":"ClaimSet","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"issuer","type":"address"},{"indexed":true,"name":"subject","type":"address"},{"indexed":true,"name":"key","type":"bytes32"},{"indexed":false,"name":"removedAt","type":"uint256"}],"name":"ClaimRemoved","type":"event"}];

// - The contract address 
//let contractAddress = '0x09f739d39b179e382d743d48be906c89e11d2389';   // - alpha contrct address
let contractAddress = '0x1c4641dfee7c18bd816365e93257e07b9ac6e659';     // - beta / delta contrct address
console.log('contractAddress = ' + contractAddress);

// - The default Provider used for contract connection and no gas calls
let contractInstance = new ethers.Contract(contractAddress, contractAbi, provider);
if (debug) console.log('---contractInstance = ');
if (debug) console.log(contractInstance);           

// - The wallet setup to pay the gas
let privateKey = '36319AD42B89D5A21A534E174174AD57D3B13C044ED1706326F28D26EA1F0AF7';
let wallet = new ethers.Wallet(privateKey, provider);
if (debug) console.log('---wallet = ');
if (debug) console.log(wallet);                     

// - The Contract Instance with Signer, which allows gas calls
let contractWithSigner = contractInstance.connect(wallet);
if (debug) console.log('---contractWithSigner = ');
if (debug) console.log(contractWithSigner);          

// - The contract arguments
let subject = '0xE1aAaba34F7011fEBdcDA766E78C92052d16980a';

// - The contract arguments sections below are used to setup three different tests
//let key = 'Alpha Claim Key' // - The Alpha Claim Key
//let key = 'Beta Claim Key' // - The Beta Claim Key
let key = 'Delta Claim Key' // - The Delta Claim Key

//let keyValue = 'Alpha Claim Key Value: Node' // - The Alpha Claim Value
//let keyValue = 'Beta Claim Key Value: Node' // - The Beta Claim Value
let keyValue = 'Deta Claim Key Value: Node' // - The Deta Claim Value    

// - The encode to Bytes32
let keyEncoded = ethers.utils.formatBytes32String(key);
let keyValueEncoded = ethers.utils.formatBytes32String(keyValue);         

// - The contract arguments output to console 
console.log('---contractInstance.setClaim called with: ' 
                + subject + ', \''  
                + keyEncoded + '\', \'' 
                + keyValueEncoded + '\'' );

// - The contract execution
contractWithSigner.setClaim(subject, keyEncoded, keyValueEncoded).then(
    function(result) { 
        console.log('result = ');
        console.log(result);
        
    },
    function(error) { console.log( error) }
);        

console.log('End -------');
