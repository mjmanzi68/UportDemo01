
console.log('Start -------');

const Web3 = require('web3');
let web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));

web3.eth.defaultAccount = '0xe7ef530692714d21101c2b86aae33b79dfa9e7aa';
console.log('---web3.eth.defaultAccount = ' + web3.eth.defaultAccount);

var abi = [{"constant":false,"inputs":[{"name":"key","type":"bytes32"},{"name":"value","type":"bytes32"}],"name":"setSelfClaim","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"subject","type":"address"},{"name":"key","type":"bytes32"},{"name":"value","type":"bytes32"}],"name":"setClaim","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"issuer","type":"address"},{"name":"subject","type":"address"},{"name":"key","type":"bytes32"}],"name":"removeClaim","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"issuer","type":"address"},{"name":"subject","type":"address"},{"name":"key","type":"bytes32"}],"name":"getClaim","outputs":[{"name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"},{"name":"","type":"address"},{"name":"","type":"bytes32"}],"name":"registry","outputs":[{"name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"anonymous":false,"inputs":[{"indexed":true,"name":"issuer","type":"address"},{"indexed":true,"name":"subject","type":"address"},{"indexed":true,"name":"key","type":"bytes32"},{"indexed":false,"name":"value","type":"bytes32"},{"indexed":false,"name":"updatedAt","type":"uint256"}],"name":"ClaimSet","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"issuer","type":"address"},{"indexed":true,"name":"subject","type":"address"},{"indexed":true,"name":"key","type":"bytes32"},{"indexed":false,"name":"removedAt","type":"uint256"}],"name":"ClaimRemoved","type":"event"}];
var address = '0x09f739d39b179e382d743d48be906c89e11d2389'

var contractABI = web3.eth.contract(abi, address);
var contractInstance = contractABI.at(address);
console.log('---instantiated contract instance');
//console.log(contractInstance) // - long output so commented out

web3.personal.unlockAccount(web3.eth.defaultAccount, "password", 600);
console.log('---Account unlocked!');

const SHA256 = require('crypto-js/sha256');
let claimKeyHash = SHA256('TestClaim').toString();
let claimDataHash = SHA256(JSON.stringify({'name':'Jonathan'})).toString();

var result = contractInstance.setClaim(web3.eth.defaultAccount,claimKeyHash,claimDataHash)
console.log('---contractInstance.setClaim(' + web3.eth.defaultAccount + '\',\'' + claimKeyHash + '\',\'' + claimDataHash + '\)');
console.log('---contractInstance.setClaim called with data = ' + result);

console.log('End -------');

