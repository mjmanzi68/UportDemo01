
const ethers = require('ethers');

// - Alpha Key Value
let keyDataEncoded = '0x416c70686120436c61696d204b65792056616c75653a204e6f64650000000000'

let keyDataDecoded = ethers.utils.parseBytes32String (keyDataEncoded);   

console.log('keyDataEncoded = ' + keyDataEncoded);
console.log('keyDataDecoded = ' + keyDataDecoded);