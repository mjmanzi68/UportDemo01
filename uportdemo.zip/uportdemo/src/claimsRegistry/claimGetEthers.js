
const ethers = require('ethers');

console.log('Start -------');
let debug = false; // - printout is very long

// - The connection to the network using the default: http://localhost:8545
let provider = new ethers.providers.JsonRpcProvider();  

// - The Contract interface
let contractAbi = [{"constant":false,"inputs":[{"name":"key","type":"bytes32"},{"name":"value","type":"bytes32"}],"name":"setSelfClaim","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"subject","type":"address"},{"name":"key","type":"bytes32"},{"name":"value","type":"bytes32"}],"name":"setClaim","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"issuer","type":"address"},{"name":"subject","type":"address"},{"name":"key","type":"bytes32"}],"name":"removeClaim","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"issuer","type":"address"},{"name":"subject","type":"address"},{"name":"key","type":"bytes32"}],"name":"getClaim","outputs":[{"name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"},{"name":"","type":"address"},{"name":"","type":"bytes32"}],"name":"registry","outputs":[{"name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"anonymous":false,"inputs":[{"indexed":true,"name":"issuer","type":"address"},{"indexed":true,"name":"subject","type":"address"},{"indexed":true,"name":"key","type":"bytes32"},{"indexed":false,"name":"value","type":"bytes32"},{"indexed":false,"name":"updatedAt","type":"uint256"}],"name":"ClaimSet","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"issuer","type":"address"},{"indexed":true,"name":"subject","type":"address"},{"indexed":true,"name":"key","type":"bytes32"},{"indexed":false,"name":"removedAt","type":"uint256"}],"name":"ClaimRemoved","type":"event"}];

// - The contract address 
//let contractAddress = '0x09f739d39b179e382d743d48be906c89e11d2389';     // - alpha contract address
let contractAddress = '0x1c4641dfee7c18bd816365e93257e07b9ac6e659';   // - beta / delta contract address
console.log('contractAddress = ' + contractAddress);

// - The default Provider used for contract connection and no gas calls
let contractInstance = new ethers.Contract(contractAddress, contractAbi, provider);
if (debug) console.log('---contractInstance = ');
if (debug) console.log(contractInstance);           

// - The contract arguments
let issuer = '0xcF0362906a607b9AF27Da8d51893F89c67babF19'
let subject = '0xE1aAaba34F7011fEBdcDA766E78C92052d16980a';

// - The contract arguments section is used to setup three different tests
//let key = 'Alpha Claim Key' // - The Alpha Claim Key
//let key = 'Beta Claim Key' // - The Beta Claim Key
let key = 'Delta Claim Key' // - The Delta Claim Key

// - The encode to Bytes32
let keyEncoded = ethers.utils.formatBytes32String(key);

// - The contract arguments output to console 
console.log('---contractInstance.getClaim called with: ' 
            + issuer + ', ' 
            + subject + ', \''  
            + keyEncoded + '\'' );

// - The contract execution
contractInstance.getClaim(issuer, subject, keyEncoded).then(
    function(result) { 
        let keyDataDecoded = ethers.utils.parseBytes32String(result)
        console.log('--key = ' + key);
        console.log('--keydata bytes32 = ' + result) 
        console.log('--keyData Decoded = ' + keyDataDecoded);
        console.log('End -------');
    },
    function(error) { console.log( error) }
);        

